﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CE = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.One = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.Equal_To = new System.Windows.Forms.Button();
            this.Addition = new System.Windows.Forms.Button();
            this.Substraction = new System.Windows.Forms.Button();
            this.Multiplication = new System.Windows.Forms.Button();
            this.Division = new System.Windows.Forms.Button();
            this.Dot = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.Erase = new System.Windows.Forms.Button();
            this.historyTxtBox = new System.Windows.Forms.RichTextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.Standard = new System.Windows.Forms.Label();
            this.History = new System.Windows.Forms.Label();
            this.Memory = new System.Windows.Forms.Label();
            this.txtDisplay = new System.Windows.Forms.RichTextBox();
            this.ShowOpt = new System.Windows.Forms.Label();
            this.lblHistoryDisplay = new System.Windows.Forms.Label();
            this.Plus_Minus = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CE
            // 
            this.CE.BackColor = System.Drawing.Color.Gainsboro;
            this.CE.FlatAppearance.BorderSize = 0;
            this.CE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CE.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CE.Location = new System.Drawing.Point(3, 250);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(90, 69);
            this.CE.TabIndex = 0;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = false;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // Seven
            // 
            this.Seven.BackColor = System.Drawing.Color.Gainsboro;
            this.Seven.FlatAppearance.BorderSize = 0;
            this.Seven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Seven.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seven.Location = new System.Drawing.Point(3, 325);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(90, 69);
            this.Seven.TabIndex = 0;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = false;
            this.Seven.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Four
            // 
            this.Four.BackColor = System.Drawing.Color.Gainsboro;
            this.Four.FlatAppearance.BorderSize = 0;
            this.Four.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Four.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Four.Location = new System.Drawing.Point(3, 400);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(90, 69);
            this.Four.TabIndex = 0;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = false;
            this.Four.Click += new System.EventHandler(this.Numbers_only);
            // 
            // One
            // 
            this.One.BackColor = System.Drawing.Color.Gainsboro;
            this.One.FlatAppearance.BorderSize = 0;
            this.One.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.One.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.One.Location = new System.Drawing.Point(3, 475);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(90, 69);
            this.One.TabIndex = 0;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = false;
            this.One.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Zero
            // 
            this.Zero.BackColor = System.Drawing.Color.Gainsboro;
            this.Zero.FlatAppearance.BorderSize = 0;
            this.Zero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Zero.Location = new System.Drawing.Point(99, 550);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(90, 69);
            this.Zero.TabIndex = 1;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = false;
            this.Zero.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Two
            // 
            this.Two.BackColor = System.Drawing.Color.Gainsboro;
            this.Two.FlatAppearance.BorderSize = 0;
            this.Two.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Two.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Two.Location = new System.Drawing.Point(99, 475);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(90, 69);
            this.Two.TabIndex = 2;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = false;
            this.Two.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Five
            // 
            this.Five.BackColor = System.Drawing.Color.Gainsboro;
            this.Five.FlatAppearance.BorderSize = 0;
            this.Five.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Five.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Five.Location = new System.Drawing.Point(99, 400);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(90, 69);
            this.Five.TabIndex = 3;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = false;
            this.Five.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Eight
            // 
            this.Eight.BackColor = System.Drawing.Color.Gainsboro;
            this.Eight.FlatAppearance.BorderSize = 0;
            this.Eight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Eight.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eight.Location = new System.Drawing.Point(99, 325);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(90, 69);
            this.Eight.TabIndex = 4;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = false;
            this.Eight.Click += new System.EventHandler(this.Numbers_only);
            // 
            // C
            // 
            this.C.BackColor = System.Drawing.Color.Gainsboro;
            this.C.FlatAppearance.BorderSize = 0;
            this.C.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.C.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C.Location = new System.Drawing.Point(99, 250);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(90, 69);
            this.C.TabIndex = 5;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = false;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // Equal_To
            // 
            this.Equal_To.BackColor = System.Drawing.Color.Gainsboro;
            this.Equal_To.FlatAppearance.BorderSize = 0;
            this.Equal_To.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Equal_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equal_To.Location = new System.Drawing.Point(291, 550);
            this.Equal_To.Name = "Equal_To";
            this.Equal_To.Size = new System.Drawing.Size(90, 69);
            this.Equal_To.TabIndex = 13;
            this.Equal_To.Text = "=";
            this.Equal_To.UseVisualStyleBackColor = false;
            this.Equal_To.Click += new System.EventHandler(this.Equal_To_Click);
            // 
            // Addition
            // 
            this.Addition.BackColor = System.Drawing.Color.Gainsboro;
            this.Addition.FlatAppearance.BorderSize = 0;
            this.Addition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addition.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addition.Location = new System.Drawing.Point(291, 475);
            this.Addition.Name = "Addition";
            this.Addition.Size = new System.Drawing.Size(90, 69);
            this.Addition.TabIndex = 14;
            this.Addition.Text = "+";
            this.Addition.UseVisualStyleBackColor = false;
            this.Addition.Click += new System.EventHandler(this.Operators_Click);
            // 
            // Substraction
            // 
            this.Substraction.BackColor = System.Drawing.Color.Gainsboro;
            this.Substraction.FlatAppearance.BorderSize = 0;
            this.Substraction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Substraction.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Substraction.Location = new System.Drawing.Point(291, 400);
            this.Substraction.Name = "Substraction";
            this.Substraction.Size = new System.Drawing.Size(90, 69);
            this.Substraction.TabIndex = 15;
            this.Substraction.Text = "-";
            this.Substraction.UseVisualStyleBackColor = false;
            this.Substraction.Click += new System.EventHandler(this.Operators_Click);
            // 
            // Multiplication
            // 
            this.Multiplication.BackColor = System.Drawing.Color.Gainsboro;
            this.Multiplication.FlatAppearance.BorderSize = 0;
            this.Multiplication.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Multiplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiplication.Location = new System.Drawing.Point(291, 325);
            this.Multiplication.Name = "Multiplication";
            this.Multiplication.Size = new System.Drawing.Size(90, 69);
            this.Multiplication.TabIndex = 16;
            this.Multiplication.Text = "x";
            this.Multiplication.UseVisualStyleBackColor = false;
            this.Multiplication.Click += new System.EventHandler(this.Operators_Click);
            // 
            // Division
            // 
            this.Division.BackColor = System.Drawing.Color.Gainsboro;
            this.Division.FlatAppearance.BorderSize = 0;
            this.Division.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Division.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Division.Location = new System.Drawing.Point(291, 250);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(90, 69);
            this.Division.TabIndex = 17;
            this.Division.Text = "/";
            this.Division.UseVisualStyleBackColor = false;
            this.Division.Click += new System.EventHandler(this.Operators_Click);
            // 
            // Dot
            // 
            this.Dot.BackColor = System.Drawing.Color.Gainsboro;
            this.Dot.FlatAppearance.BorderSize = 0;
            this.Dot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dot.Location = new System.Drawing.Point(195, 550);
            this.Dot.Name = "Dot";
            this.Dot.Size = new System.Drawing.Size(90, 69);
            this.Dot.TabIndex = 7;
            this.Dot.Text = ".";
            this.Dot.UseVisualStyleBackColor = false;
            this.Dot.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Three
            // 
            this.Three.BackColor = System.Drawing.Color.Gainsboro;
            this.Three.FlatAppearance.BorderSize = 0;
            this.Three.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Three.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Three.Location = new System.Drawing.Point(195, 475);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(90, 69);
            this.Three.TabIndex = 8;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = false;
            this.Three.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Six
            // 
            this.Six.BackColor = System.Drawing.Color.Gainsboro;
            this.Six.FlatAppearance.BorderSize = 0;
            this.Six.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Six.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Six.Location = new System.Drawing.Point(195, 400);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(90, 69);
            this.Six.TabIndex = 9;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = false;
            this.Six.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Nine
            // 
            this.Nine.BackColor = System.Drawing.Color.Gainsboro;
            this.Nine.FlatAppearance.BorderSize = 0;
            this.Nine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nine.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nine.Location = new System.Drawing.Point(195, 325);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(90, 69);
            this.Nine.TabIndex = 10;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = false;
            this.Nine.Click += new System.EventHandler(this.Numbers_only);
            // 
            // Erase
            // 
            this.Erase.BackColor = System.Drawing.Color.Gainsboro;
            this.Erase.FlatAppearance.BorderSize = 0;
            this.Erase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Erase.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Erase.Location = new System.Drawing.Point(195, 250);
            this.Erase.Name = "Erase";
            this.Erase.Size = new System.Drawing.Size(90, 69);
            this.Erase.TabIndex = 11;
            this.Erase.Text = "Erase";
            this.Erase.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Erase.UseVisualStyleBackColor = false;
            this.Erase.Click += new System.EventHandler(this.Erase_Click);
            // 
            // historyTxtBox
            // 
            this.historyTxtBox.Location = new System.Drawing.Point(628, 165);
            this.historyTxtBox.Name = "historyTxtBox";
            this.historyTxtBox.Size = new System.Drawing.Size(143, 422);
            this.historyTxtBox.TabIndex = 19;
            this.historyTxtBox.Text = "";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(696, 604);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 20;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Standard
            // 
            this.Standard.AutoSize = true;
            this.Standard.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Standard.Location = new System.Drawing.Point(53, 4);
            this.Standard.Name = "Standard";
            this.Standard.Size = new System.Drawing.Size(107, 25);
            this.Standard.TabIndex = 21;
            this.Standard.Text = "Standard";
            // 
            // History
            // 
            this.History.AutoSize = true;
            this.History.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.Location = new System.Drawing.Point(353, 9);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(86, 25);
            this.History.TabIndex = 21;
            this.History.Text = "Hsitory";
            // 
            // Memory
            // 
            this.Memory.AutoSize = true;
            this.Memory.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Memory.Location = new System.Drawing.Point(623, 9);
            this.Memory.Name = "Memory";
            this.Memory.Size = new System.Drawing.Size(95, 25);
            this.Memory.TabIndex = 21;
            this.Memory.Text = "Memory";
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(7, 99);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtDisplay.Size = new System.Drawing.Size(378, 86);
            this.txtDisplay.TabIndex = 22;
            this.txtDisplay.Text = "0";
            // 
            // ShowOpt
            // 
            this.ShowOpt.AutoSize = true;
            this.ShowOpt.Location = new System.Drawing.Point(253, 60);
            this.ShowOpt.Name = "ShowOpt";
            this.ShowOpt.Size = new System.Drawing.Size(0, 13);
            this.ShowOpt.TabIndex = 23;
            // 
            // lblHistoryDisplay
            // 
            this.lblHistoryDisplay.AutoSize = true;
            this.lblHistoryDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistoryDisplay.Location = new System.Drawing.Point(423, 48);
            this.lblHistoryDisplay.Name = "lblHistoryDisplay";
            this.lblHistoryDisplay.Size = new System.Drawing.Size(271, 29);
            this.lblHistoryDisplay.TabIndex = 24;
            this.lblHistoryDisplay.Text = "There is no history yet";
            // 
            // Plus_Minus
            // 
            this.Plus_Minus.BackColor = System.Drawing.Color.Gainsboro;
            this.Plus_Minus.FlatAppearance.BorderSize = 0;
            this.Plus_Minus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Plus_Minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Plus_Minus.Location = new System.Drawing.Point(3, 550);
            this.Plus_Minus.Name = "Plus_Minus";
            this.Plus_Minus.Size = new System.Drawing.Size(90, 69);
            this.Plus_Minus.TabIndex = 0;
            this.Plus_Minus.Text = "+/-";
            this.Plus_Minus.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 651);
            this.Controls.Add(this.lblHistoryDisplay);
            this.Controls.Add(this.ShowOpt);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.Memory);
            this.Controls.Add(this.History);
            this.Controls.Add(this.Standard);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.historyTxtBox);
            this.Controls.Add(this.Equal_To);
            this.Controls.Add(this.Addition);
            this.Controls.Add(this.Substraction);
            this.Controls.Add(this.Multiplication);
            this.Controls.Add(this.Division);
            this.Controls.Add(this.Dot);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.Erase);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.C);
            this.Controls.Add(this.Plus_Minus);
            this.Controls.Add(this.One);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.CE);
            this.MaximumSize = new System.Drawing.Size(789, 690);
            this.MinimumSize = new System.Drawing.Size(420, 690);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button Seven;
        private System.Windows.Forms.Button Four;
        private System.Windows.Forms.Button One;
        private System.Windows.Forms.Button Zero;
        private System.Windows.Forms.Button Two;
        private System.Windows.Forms.Button Five;
        private System.Windows.Forms.Button Eight;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button Equal_To;
        private System.Windows.Forms.Button Addition;
        private System.Windows.Forms.Button Substraction;
        private System.Windows.Forms.Button Multiplication;
        private System.Windows.Forms.Button Division;
        private System.Windows.Forms.Button Dot;
        private System.Windows.Forms.Button Three;
        private System.Windows.Forms.Button Six;
        private System.Windows.Forms.Button Nine;
        private System.Windows.Forms.Button Erase;
        private System.Windows.Forms.RichTextBox historyTxtBox;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Label Standard;
        private System.Windows.Forms.Label History;
        private System.Windows.Forms.Label Memory;
        private System.Windows.Forms.RichTextBox txtDisplay;
        private System.Windows.Forms.Label ShowOpt;
        private System.Windows.Forms.Label lblHistoryDisplay;
        private System.Windows.Forms.Button Plus_Minus;
    }
}

